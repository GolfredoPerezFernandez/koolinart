import { createContext } from "react";
// import { Moralis } from "moralis-v1";
import { useMoralis } from "react-moralis";
import { useBoundStore } from "@/store/index";
import { shallow } from "zustand/shallow";
import { tokenAbicode, tokenErc721Abi } from "@/config/abi";
import Web3 from "web3";
import useSetIpfsUploadFolder from "@/hooks/useSetIpfsUploadFolder";

interface CreateCollectionValues {
  theFile: undefined | File;
  nameCollection: string;
  symbol: string;
  descriptionCollection: string;
}

type CreateNftContextType = {
  GetCollectionItemsCreateNft: () => Promise<void>;
  CreateCollection: (value: CreateCollectionValues) => Promise<void>;
  SetCollectionFilePath: (collection: string) => Promise<void>;
} | null;

export const CreateNftContext = createContext<CreateNftContextType>(null);

const CreateNftState = (props: { children: any }) => {
  const {
    ChangeCollectionsItems,
    UserRender,
    LoginType,
    ChangeCollectionFilePath,
    ChangeOpenStepper,
    ChangeTypeStepper,
    ChangeIndexProcess,
    ChangeErrorProcess,
    TypeStepperCollection,
  } = useBoundStore((state: any) => state, shallow);
  const { Moralis }: any = useMoralis();
  const ethers = Moralis.web3Library;
  const mnemonic = UserRender.attributes?.mnemonic
    ? UserRender.attributes.mnemonic
    : "";
  const ethAddress = UserRender.attributes?.ethAddress
    ? UserRender.attributes.ethAddress.toString().toLowerCase()
    : "";

  const GetCollectionItemsCreateNft = async () => {
    try {
      let resultCollection: any = await Moralis.Cloud.run(
        "getCollectionSelect",
        { userAddress: ethAddress }
      );
      ChangeCollectionsItems(resultCollection);
    } catch (error: any) {
      const errorMessage = JSON.stringify(error);
      const errorObject = JSON.parse(errorMessage);
      throw errorObject.message;
    }
  };
  const SetCollectionFilePath = async (collection: string) => {
    try {
      let resultCollection: any = await Moralis.Cloud.run(
        "setColletionFilePath",
        { collection }
      );
      ChangeCollectionFilePath(resultCollection);
    } catch (error: any) {
      const errorMessage = JSON.stringify(error);
      const errorObject = JSON.parse(errorMessage);
      throw errorObject.message;
    }
  };
  const CreateCollection = async (values: CreateCollectionValues) => {
    try {
      if (!UserRender) {
        throw "unsuccessful user";
      }
      ChangeTypeStepper(TypeStepperCollection);
      ChangeOpenStepper(true);
      ChangeIndexProcess(0);

      if (LoginType === "email") {
        try {
          console.log(`values collections ${JSON.stringify(values)}`);

          const provider = new ethers.providers.WebSocketProvider(
            "wss://polygon-mainnet.g.alchemy.com/v2/D6YhiyBLvTYRDmMcwrPwQ4PcAahbxjz1"
          );

          const wallet = ethers.Wallet.fromMnemonic(mnemonic);
          const account = wallet.connect(provider);
          console.log(`values account  ${account}`);
          console.log(`values account json ${JSON.stringify(account)}`);

          const myContract = new ethers.ContractFactory(
            tokenErc721Abi,
            tokenAbicode,
            account
          );
          const contract = await myContract.deploy(
            values.nameCollection,
            values.symbol
          );

          let name = values.nameCollection;
          let symbol = values.symbol;
          let nameWithoutSpace = name.split(" ").join("");
          const data = values.theFile;
          console.log(`values ethAddress ${ethAddress}`);
          console.log(`values contract ${contract}`);
          console.log(`values contract json ${JSON.stringify(contract)}`);
          console.log(`values nameWithoutSpace json ${nameWithoutSpace}`);
          console.log(`values nameWithoutSpace json ${data}`);

          const response = await useSetIpfsUploadFolder(
            ethAddress,
            data,
            `avatarCollect-${nameWithoutSpace}.jpg`,
            false
          );
          const filePath = await response.path;
          const fileHash = await response.hash;
          console.log(`values response json ${JSON.stringify(response)}`);

          ChangeIndexProcess(1);

          const Collection = Moralis.Object.extend("CollectionsPolygon");
          const collec = new Collection();
          collec.set("name", name);
          collec.set("symbol", symbol);
          collec.set("description", values.descriptionCollection);
          collec.set("owner", ethAddress);
          collec.set("fileHash", fileHash);
          collec.set("filePath", filePath);
          collec.set("collectionAddress", contract.address.toLowerCase());
          ChangeIndexProcess(2);
          await collec.save();
          ChangeIndexProcess(3);
        } catch (error) {
          ChangeErrorProcess(true);
          const errorMessage = JSON.stringify(error);
          const errorObject = JSON.parse(errorMessage);
          throw errorObject.message;
        }
      } else {
        const web = new Web3(Moralis.provider);
        let deploy_contract = new web.eth.Contract(tokenErc721Abi);
        let gasPrice;

        let attempts = 0;
        const maxAttempts = 3;
        const timeoutDuration = 90000; // 1 minuto y 30 segundo
        while (attempts < maxAttempts) {
          try {
            gasPrice = await Promise.race([
              web.eth.getGasPrice(),
              new Promise((_, reject) =>
                setTimeout(() => reject(new Error("Timeout")), timeoutDuration)
              ),
            ]);
            break;
          } catch (error) {
            attempts++;
            if (attempts >= maxAttempts) {
              throw new Error(
                "Failed to get gas price after multiple attempts."
              );
            }
          }
        }

        const gasPriceString = gasPrice as string;

        let payload = {
          data: tokenAbicode,
          arguments: [values.nameCollection, values.symbol],
        };
        ChangeIndexProcess(1);
        var res = await deploy_contract
          .deploy(payload)
          .send(
            { from: ethAddress, gas: 9000000, gasPrice: gasPriceString },
            (err: any, transactionHash: any) => {}
          )
          .on("confirmation", () => {})
          .then(async (newContractInstance: any) => {
            try {
              const data = values.theFile;
              const response = await useSetIpfsUploadFolder(
                ethAddress,
                data,
                `avatarCollect-${values.nameCollection
                  .split(" ")
                  .join("")}.jpg`,
                false
              );

              const filePath = await response.path;
              const fileHash = await response.hash;
              const Collection = Moralis.Object.extend("CollectionsPolygon");
              const collec = new Collection();
              collec.set("name", values.nameCollection);
              collec.set("symbol", values.symbol);
              collec.set("description", values.descriptionCollection);
              collec.set("owner", ethAddress);
              collec.set("fileHash", fileHash);
              collec.set("filePath", filePath);
              collec.set(
                "collectionAddress",
                newContractInstance.options.address.toLowerCase()
              );
              ChangeIndexProcess(2);

              await collec.save();

              ChangeIndexProcess(3);
            } catch (error: any) {
              const errorMessage = JSON.stringify(error);
              const errorObjeto = JSON.parse(errorMessage);
              throw errorObjeto.message;
            }
          });
      }
      ChangeOpenStepper(false);
    } catch (error: any) {
      ChangeErrorProcess(true);
      const errorMessage = JSON.stringify(error);
      const errorObject = JSON.parse(errorMessage);
      throw errorObject.message;
    }
  };

  return (
    <CreateNftContext.Provider
      value={{
        GetCollectionItemsCreateNft,
        CreateCollection,
        SetCollectionFilePath,
      }}
    >
      {props.children}
    </CreateNftContext.Provider>
  );
};

export default CreateNftState;
